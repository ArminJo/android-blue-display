/*
 * RcCarControlBD.h
 *
 *  Created on: 02.06.2016
 *      Author: Armin
 */

#ifndef SRC_RCCARCONTROLBD_H_
#define SRC_RCCARCONTROLBD_H_

#define DIRECTION_STRAIGHT 0
#define DIRECTION_RIGHT 1
#define DIRECTION_LEFT 2

void BDsetup();
void BDloop();


#endif /* SRC_RCCARCONTROLBD_H_ */
